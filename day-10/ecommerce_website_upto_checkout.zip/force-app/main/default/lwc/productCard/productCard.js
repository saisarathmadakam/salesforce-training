import { LightningElement, api } from 'lwc';

export default class ProductCard extends LightningElement {
    @api product;

    handleViewDetails() {
        this.dispatchEvent(
            new CustomEvent('viewdetails', {
                bubbles: true,
                composed: true,
                detail: {
                    productId: this.product.Id
                }
            })
        );
    }

    handleAddToCart() {
        this.dispatchEvent(
            new CustomEvent('addtocart', {
                bubbles: true,
                composed: true,
                detail: {
                    product: this.product
                }
            })
        );
    }
}
