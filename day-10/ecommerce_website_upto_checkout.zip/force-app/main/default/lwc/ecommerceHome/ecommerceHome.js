import { LightningElement } from 'lwc';

export default class EcommerceHome extends LightningElement {
}
