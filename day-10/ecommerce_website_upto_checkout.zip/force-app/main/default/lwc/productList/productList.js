import { LightningElement, wire } from 'lwc';
import getProducts from '@salesforce/apex/ProductController.getProducts';

export default class ProductList extends LightningElement {
    products = [];
    cartItems = [];
    selectedProduct = null;
    currentView = 'products';
    error;

    @wire(getProducts)
    wiredProducts({ data, error }) {
        if (data) {
            this.products = data;
            this.error = undefined;
        } else if (error) {
            this.products = [];
            this.error = error;
            console.error('PRODUCT ERROR:', error);
        }
    }

    get isProductsView() {
        return this.currentView === 'products';
    }

    get isDetailsView() {
        return this.currentView === 'details';
    }

    get isCartView() {
        return this.currentView === 'cart';
    }

    get isCheckoutView() {
        return this.currentView === 'checkout';
    }

    get cartCount() {
        return this.cartItems.reduce(
            (total, item) => total + item.quantity,
            0
        );
    }

    get totalAmount() {
        return this.cartItems.reduce(
            (total, item) => total + item.total,
            0
        );
    }

    handleAddToCart(event) {
        console.log('ADD TO CART STARTED');

        let product = event.detail?.product;

        if (!product && event.currentTarget?.dataset?.id) {
            product = this.products.find(
                item => item.Id === event.currentTarget.dataset.id
            );
        }

        if (!product) {
            console.error('PRODUCT NOT FOUND');
            return;
        }

        console.log('PRODUCT FOUND:', product.Product_Name__c);

        const existingItem = this.cartItems.find(
            item => item.product.Id === product.Id
        );

        if (existingItem) {
            this.cartItems = this.cartItems.map(item => {
                if (item.product.Id === product.Id) {
                    const quantity = item.quantity + 1;

                    return {
                        ...item,
                        quantity: quantity,
                        total: quantity * Number(item.product.Price__c)
                    };
                }

                return item;
            });
        } else {
            this.cartItems = [
                ...this.cartItems,
                {
                    product: product,
                    quantity: 1,
                    total: Number(product.Price__c)
                }
            ];
        }

        console.log('CART UPDATED');

        this.currentView = 'cart';
    }

    handleViewDetails(event) {
        const productId = event.detail.productId;

        this.selectedProduct = this.products.find(
            product => product.Id === productId
        );

        this.currentView = 'details';
    }

    handleBackToProducts() {
        this.selectedProduct = null;
        this.currentView = 'products';
    }

    handleShowCart() {
        this.currentView = 'cart';
    }

    handleShowProducts() {
        this.currentView = 'products';
    }

    handleCheckout() {
        this.currentView = 'checkout';
    }

    handleBackToCart() {
        this.currentView = 'cart';
    }

    handlePlaceOrder(event) {
        console.log('ORDER DETAILS:', event.detail);
        alert('Order details captured successfully.');
        this.currentView = 'products';
    }

    handleIncrease(event) {
        const productId = event.currentTarget.dataset.id;

        this.cartItems = this.cartItems.map(item => {
            if (item.product.Id === productId) {
                const quantity = item.quantity + 1;

                return {
                    ...item,
                    quantity: quantity,
                    total: quantity * Number(item.product.Price__c)
                };
            }

            return item;
        });
    }

    handleDecrease(event) {
        const productId = event.currentTarget.dataset.id;

        this.cartItems = this.cartItems
            .map(item => {
                if (item.product.Id === productId) {
                    const quantity = item.quantity - 1;

                    return {
                        ...item,
                        quantity: quantity,
                        total: quantity * Number(item.product.Price__c)
                    };
                }

                return item;
            })
            .filter(item => item.quantity > 0);
    }

    handleRemove(event) {
        const productId = event.currentTarget.dataset.id;

        this.cartItems = this.cartItems.filter(
            item => item.product.Id !== productId
        );
    }
}
