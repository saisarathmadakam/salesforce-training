import { LightningElement, api } from 'lwc';

export default class Checkout extends LightningElement {
    @api cartItems = [];

    customerName = '';
    email = '';
    phone = '';
    address = '';
    city = '';
    state = '';
    pincode = '';

    get totalItems() {
        return this.cartItems.reduce(
            (total, item) => total + item.quantity,
            0
        );
    }

    get totalAmount() {
        return this.cartItems.reduce(
            (total, item) => total + item.total,
            0
        );
    }

    handleChange(event) {
        const field = event.target.name;
        this[field] = event.target.value;
    }

    handleBackToCart() {
        this.dispatchEvent(
            new CustomEvent('backtocart')
        );
    }

    handlePlaceOrder() {
        if (
            !this.customerName ||
            !this.email ||
            !this.phone ||
            !this.address ||
            !this.city ||
            !this.state ||
            !this.pincode
        ) {
            alert('Please fill all customer details.');
            return;
        }

        this.dispatchEvent(
            new CustomEvent('placeorder', {
                detail: {
                    customerName: this.customerName,
                    email: this.email,
                    phone: this.phone,
                    address: this.address,
                    city: this.city,
                    state: this.state,
                    pincode: this.pincode,
                    cartItems: this.cartItems,
                    totalItems: this.totalItems,
                    totalAmount: this.totalAmount
                }
            })
        );
    }
}
